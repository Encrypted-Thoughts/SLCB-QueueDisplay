# SLCB-QueueDisplay
A script to allow the queue to be added as a browser source in OBS and viewed similar to warpbar.
